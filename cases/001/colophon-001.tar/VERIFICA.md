# Come verificare questo registro

Il file `events.jsonl` contiene il registro degli interventi fatti mentre scrivevo
*Come rendere trasparente il tuo uso dell'AI quando scrivi un contenuto*.
Ogni riga è un evento, e ogni evento contiene l'impronta di quello precedente: la sequenza
è una catena, e **alterare un evento passato invalida tutti gli hash successivi**.

Accanto al registro trovate i file che permettono di verificarlo senza credermi sulla parola.

## 0. Il controllo più rapido

```bash
grep -E '^[0-9a-f]{64}  ' attestazione.txt | shasum -a 256 -c -
```

Ogni file su cui il registro si chiude, in un comando solo: niente PDF, niente PKI,
niente browser. Il file non è firmato di proposito — sono i suoi byte quelli che quei
digest descrivono.

**Se questo è arrivato dentro un PDF**, il registro è un allegato. Firefox apre il
pannello allegati e lo scarica; da terminale, `pdfdetach -saveall file.pdf`. **Adobe
Reader mostra l'allegato e può rifiutarsi di salvarlo** — misurato su Adobe Reader
2026.001.21789 su macOS, su ogni file provato, compresi alcuni scritti da altri strumenti.
Se succede, il documento non ha niente che non va: usate Firefox o `pdfdetach`.

**Se è arrivato come bundle** — `colophon-001.tar` — tutto quanto segue è già dentro, e
c'è anche `verify.html`: apritelo nel browser con la rete spenta e trascinateci il tar.

## Questo registro è un replay, e va detto prima di tutto il resto

Gli ottanta eventi qui dentro sono stati registrati mentre l'articolo veniva scritto, il
21-23 agosto 2026, e sono riprodotti evento per evento con le loro date originali. La
catena e il sigillo invece sono del 24 agosto: la regola canonica pubblicata in
`spec/canonical.md` rifiuta i numeri non interi nei payload, l'originale ne portava 72, e
riquotarli cambia ogni hash successivo.

L'originale ha radice `e9b049198f2849837d8c12057e516ade674316e12efd59b876a1525b5276272b`
e resta nella storia di questo repository. La misura è stata confrontata con la sua prima
di sigillare, ed è la stessa: 18 span, 337 parole, 46,0% delle parole del modello e 0,0%
delle idee. Quello che si perde è un giorno: la marca temporale originale attestava il 23
agosto, questa attesta il 24, e non è recuperabile — una marca è l'affermazione di un
terzo su byte precisi, e i byte sono cambiati.

## 1. La catena non è stata alterata

```bash
python3 record.py --verify
```

Ricalcola l'intera catena e segnala il primo anello rotto. Deve rispondere `chain intact`,
con la radice corrente.

## 2. Il registro è mio

La firma è Ed25519, staccata, nel file `events.jsonl.sig`. La mia chiave pubblica è
pubblicata su un dominio che controllo, e deliberatamente **non** dentro questa cartella:

**https://colophonmethod.com/.well-known/colophon/keys**

Una chiave pubblicata dentro la cartella che autentica dimostra solo che la cartella è
coerente con sé stessa, e chiunque lo ottiene in dieci secondi generando una chiave nuova
e rifirmando. La copia qui accanto resta, per riprodurre la verifica fra dieci anni senza
rete; l'ancora è quella pubblicata altrove.

```bash
echo 'f.chinaglia@gmail.com namespaces="colophon" ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIFBuJGGXqAqAZ0PqK6Fd5743SwJIJhrYd/S2S5tHZUg1 colophon' > allowed_signers
ssh-keygen -Y verify -f allowed_signers -I f.chinaglia@gmail.com \
           -n colophon -s events.jsonl.sig < events.jsonl
```

Deve rispondere `Good "colophon" signature`.

## 3. Il registro esisteva già a quella data

Due marche temporali indipendenti, per non dipendere da un solo garante.

**RFC 3161** — `events.jsonl.tsr`. Il secondo comando è quello che verifica; il primo
stampa soltanto ciò che il token dichiara.

```bash
openssl ts -reply -in events.jsonl.tsr -text | grep "Time stamp"
openssl ts -verify -data events.jsonl -in events.jsonl.tsr \
           -CAfile "$(openssl version -d | sed 's/.*"\(.*\)"/\1/')/cert.pem"
```

Deve rispondere `Verification: OK`. Quel `-CAfile` è **il bundle di certificati del vostro
sistema**: la marca viene da un'autorità che ci si aggancia, quindi non c'è niente da
scaricare. Nessun certificato radice viaggia dentro il bundle, ed è voluto — una CA che
arriva dentro le evidenze che autentica non dimostra niente, per lo stesso motivo per cui
non lo dimostra una chiave pubblicata nella cartella che firma.

Il verificatore nel browser fa meno di questo comando, di proposito: legge l'impronta e
l'ora dal token e si ferma. Vi dice che la marca impegna *questo* registro; non vi dice
chi l'ha emessa. Per quello serve il comando qui sopra.

**OpenTimestamps** — `events.jsonl.ots`, *sottomesso* per l'ancoraggio nella blockchain
Bitcoin:

```bash
pip install opentimestamps-client
ots upgrade events.jsonl.ots && ots verify events.jsonl.ots
```

Due precisazioni oneste, perché questo è il sigillo che si sopravvaluta più facilmente. Un
file `.ots` significa che il registro è stato *sottomesso*: i calendari accorpano le
sottomissioni in una transazione Bitcoin, e si è osservato che ne accettino una senza mai
ancorarla, quindi è `ots upgrade` che trasforma una sottomissione in una prova. E
verificare il risultato richiede un nodo Bitcoin, o un block explorer che decidete di
credere: non dipende da nessuna *autorità*, che non è la stessa cosa che non dipendere da
niente.

## 4. Il testo corrisponde all'annotazione

```bash
python3 measure.py
```

Deve dire `reconstruction: OK`: gli span annotati, concatenati, riproducono esattamente il
testo pubblicato. Nessun intervento è attribuito a un testo che non esiste, e nessun testo
è rimasto senza attribuzione.

Il controllo di copertura segnala alcuni orfani, ed è atteso: sono le cancellazioni, che per
definizione non hanno uno span nel testo finale, le correzioni ai blocchi esclusi dal
conteggio, e i blocchi toccati da più di una correzione, perché il formato accetta un solo
riferimento a evento per span. Ogni orfano è spiegato in un evento `register_note`.

## 5. Gli artefatti sono quelli firmati

L'ultimo evento del registro contiene il digest SHA-256 di ogni file su cui la misura si
appoggia: il testo finale, l'annotazione, la misurazione, gli span, `case.json`, l'icona,
la pagina di verifica, questo file e ogni script che un lettore rilancia. Il modo più
rapido di controllarli tutti è il §0. A mano:

```bash
shasum -a 256 versions/v22_final.txt annotation.json kpi.json spans.json icon.svg
```

Fuori dal manifest, deliberatamente: i rendering per la pubblicazione — l'articolo in PDF
e lo script che lo produce — e il bundle. Un rendering è derivabile da ciò che è coperto e
porta una riga tecnica che si può generare **solo dopo** il sigillo, quindi congelarlo
vieterebbe il passo stesso che il metodo richiede. Il bundle contiene il manifest, quindi
il manifest non può contenere il bundle: è trasporto, non evidenza, e ogni *file* dentro
di esso viene comunque confrontato con il manifest.

---

## Cosa tutto questo dimostra, e cosa no

**Dimostra** che il registro esisteva in quella forma a quella data, che non è stato alterato
da allora, e che è stato prodotto da chi possiede quella chiave.

**Non dimostra che il registro sia completo.** Nessun sistema volontario può dimostrarlo:
posso registrare tutto fedelmente oppure omettere, e la crittografia non distingue i due casi.
Il registro è inoltre compilato dal modello linguistico su sé stesso.

Lo dico per primo perché è la critica più solida che si possa fare a una dichiarazione
volontaria, ed è giusta: **il valore di questo registro non sta nella prova, sta nella
responsabilità che mi assumo pubblicandolo e nel fatto che sia ispezionabile.**

Un'ultima cosa, dichiarata e non nascosta: durante la lavorazione il modello ha distrutto
un file di versione con una scrittura sbagliata, e il controllo di ricostruzione è passato
lo stesso perché confrontava due testi entrambi vuoti. A trovarlo è stato il controllo di
copertura. L'incidente è nel registro, con la diagnosi e il recupero.

Se trovate un'incoerenza, scrivetemi: **f.chinaglia@gmail.com**

---

*MIT License — Copyright (c) 2026 Fabio Chinaglia.*
